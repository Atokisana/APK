[app]
# Informations de l'application
title = CENAD
package.name = cenad
package.domain = org.cenad

# Fichier principal
source.dir = .
source.include_exts = py,kv,png,jpg,sqlite,db,csv,json
source.include_patterns = assets/*,data/*,screens/*

version = 1.0.0

# Dépendances Python
requirements = python3,kivy==2.3.0,sqlite3,pandas,numpy,scipy,matplotlib,pillow

# Orientation portrait uniquement (smartphone)
orientation = portrait

# Android
android.permissions = WRITE_EXTERNAL_STORAGE,READ_EXTERNAL_STORAGE

# API Android
android.api = 33
android.minapi = 21
android.ndk = 25b
android.sdk = 33

# Architecture ARM 32 bits (milieu de gamme)
android.archs = armeabi-v7a

# Optimisations
android.release_artifact = apk
android.debug = False

# Icône et splash
#android.icon.filename = %(source.dir)s/assets/logo.png
#android.presplash.filename = %(source.dir)s/assets/splash.png

# Couleur du fond splash
android.presplash_color = #111B4E

# Gradle
android.gradle_dependencies =

# Permissions
android.add_jars =

# NDK API
android.ndk_api = 21

# Log niveau (2 = warnings seulement, réduit taille APK logs)
log_level = 2

# Optimisation mémoire
android.wakelock = False

[buildozer]
# Répertoire de build
log_level = 2
warn_on_root = 1

# Nettoyage avant build
# buildozer android clean && buildozer android debug
